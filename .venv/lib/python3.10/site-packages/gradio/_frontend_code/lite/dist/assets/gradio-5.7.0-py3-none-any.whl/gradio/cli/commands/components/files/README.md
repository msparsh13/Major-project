---
tags: [gradio-custom-component<<template>><<tags>>]
title: <<title>>
short_description: <<short-description>>
colorFrom: blue
colorTo: yellow
sdk: gradio
pinned: false
app_file: space.py
---

# <<title>>

You can auto-generate documentation for your custom component with the `gradio cc docs` command.
You can also edit this file however you like.

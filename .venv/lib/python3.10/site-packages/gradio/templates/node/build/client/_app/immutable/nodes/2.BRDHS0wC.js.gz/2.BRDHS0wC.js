import { z, _ } from "../chunks/2.D0qTZBJI.js";
export {
  z as component,
  _ as universal
};
